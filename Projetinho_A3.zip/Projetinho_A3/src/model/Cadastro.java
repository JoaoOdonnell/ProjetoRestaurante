package model;

public abstract class Cadastro {

	public abstract void cadastrar();
	
	public abstract void mostrar();
	
	public abstract void editar();
}
