package model;

import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class FazerPedido {

	private ArrayList<Restaurante> restaurantes ;

	public FazerPedido(ArrayList<Restaurante> restaurantes) {
		super();
		this.restaurantes = restaurantes;
	}

	Scanner sc = new Scanner(System.in);

	public void pedidos() {

		// para pegar o horário atual
		Date relogio = new Date();

		System.out.println("Qual restaurante deseja fazer um pedido?");
		// Pegando a lista dos restaurantes usando "size" e mostrando para o usuario
		// usando index
		for (int i = 0; i < restaurantes.size(); i++) {
			System.out.println(i + "-" + restaurantes.get(i).getnomeRestaurante());
		}
		// escolhendo o restaurante selecionado
		int indexRestauranteSelecionado = sc.nextInt();
		Restaurante restauranteSelecionado = restaurantes.get(indexRestauranteSelecionado);

		System.out.println("Agora escolha o prato que deseja pedir: ");

		for (int i = 0; i < restauranteSelecionado.getPratos().size(); i++) {
			System.out.println(i + "-" + restauranteSelecionado.getPratos().get(i).getNome());
		}
		int indexPratoSelecionado = sc.nextInt();
		Prato pratoSelecionado = restauranteSelecionado.getPratos().get(indexPratoSelecionado);

		int opPagamento;
		System.out.println("Certo! agora escolha uma forma de pagamento: ");
		System.out.println("1- Dinheiro");
		System.out.println("2- Cartao");
		opPagamento = sc.nextInt();
		System.out.println("*** PEDIDO EFETUADO COM SUCESSO! ***");
		System.out.println("Horario do pedido: " + relogio.toString());
	}

	public void mostrarPedidos() {
		System.out.println("*** PEDIDOS ***");
		pedidos();
	}
}
