package model;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class CadastroPratos extends Cadastro{

	Scanner sc = new Scanner(System.in);
	Prato pratos = new Prato();
	private ArrayList<Restaurante> restaurantesCadastrados;
	
	//construtor
	public CadastroPratos(ArrayList<Restaurante> restaurantesCadastrados) {
		super();
		this.restaurantesCadastrados = restaurantesCadastrados;
	}

	@Override
	public void cadastrar() {
		
		System.out.println("Escolha qual restaurante voce quer cadastrar um prato: ");

		for (int i = 0; i < restaurantesCadastrados.size(); i++) {
			System.out.println(i + "-" + restaurantesCadastrados.get(i).getnomeRestaurante());
		}
		int indexRestauranteSelecionado = sc.nextInt();
		Restaurante restauranteSelecionado = restaurantesCadastrados.get(indexRestauranteSelecionado);

		System.out.println("| Digite o nome prato:             	          |");
		sc.nextLine();
		pratos.setNome(sc.nextLine());

		System.out.println("| Digite a descricao do prato:        		  |");
		pratos.setDescricao(sc.nextLine());

		// do while para delimitar o preco
		do {
			System.out.println("| Digite o valor do prato:       		  |");
			pratos.setPreco(sc.nextDouble());
			if (pratos.getPreco() <= 0) {
				System.out.println("Erro! Valor invalido");
			}
		} while (pratos.getPreco() <= 0);
		
		System.out.println("*** PRATO CADASTRADO COM SUCESSO!!! ***");

		restauranteSelecionado.getPratos().add(pratos);
	}
	
	@Override
	public void mostrar() {
		
	}
	
	@Override
	public void editar() {
		System.out.println("Escolha o restaurante:"); 
		
		for (int i = 0; i < restaurantesCadastrados.size(); i++) {
			System.out.println(i + "-" + restaurantesCadastrados.get(i).getnomeRestaurante());
		}
		int indexRestauranteSelecionado = sc.nextInt();
		Restaurante restauranteSelecionado = restaurantesCadastrados.get(indexRestauranteSelecionado);
		
		System.out.println("Agora escolha o prato que deseja editar: ");
		
		for (int i = 0; i < restauranteSelecionado.getPratos().size(); i++) {
			System.out.println(i + "-" + restauranteSelecionado.getPratos().get(i).getNome());
		}
		int indexPratoSelecionado = sc.nextInt();
		Prato pratoSelecionado = restauranteSelecionado.getPratos().get(indexPratoSelecionado);
		
		System.out.println("| Digite o nome prato:             	          |");
		sc.nextLine();
		pratoSelecionado.setNome(sc.nextLine());

		System.out.println("| Digite a descricao do prato:        		  |");
		pratoSelecionado.setDescricao(sc.nextLine());

		// do while para delimitar o preco
		do {
			System.out.println("| Digite o valor do prato:       		  |");
			pratoSelecionado.setPreco(sc.nextDouble());
			if (pratoSelecionado.getPreco() <= 0) {
				System.out.println("Erro! Valor invalido");
			}
		} while (pratoSelecionado.getPreco() <= 0);
		
		System.out.println("*** PRATO EDITADO COM SUCESSO!!! ***");
	}


}
