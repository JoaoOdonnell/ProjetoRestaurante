package model;

import java.util.Scanner;
import java.util.ArrayList; // import the ArrayList class
import java.util.List;
import java.io.*;

public class CadastroRestaurante extends Cadastro {

	// ArrayList

	ArrayList<Restaurante> lista;

	public CadastroRestaurante(ArrayList<Restaurante> lista) {
		super();
		this.lista = lista;
	}

	Restaurante resum = new Restaurante();

	public ArrayList<Restaurante> getLista() {
		return lista;
	}

	public void setLista(ArrayList<Restaurante> lista) {
		this.lista = lista;
	}

	// adicionar restaurante
	public void adicionarRes(Restaurante res1) {
		this.lista.add(res1);
	}

	Scanner scr = new Scanner(System.in);

	

	@Override
	public void cadastrar() {
		Restaurante rte = new Restaurante();
		System.out.println(" _________________________________________________");
		System.out.println("|        	Cadastro de Restaurante    		      |");
		System.out.println("|_________________________________________________|");
		System.out.println("|                                     	          |");

		System.out.println("|Nome do Restaurante:                         ");
		rte.setnomeRestaurante(scr.nextLine());

		System.out.println("|Endereco do restaurante:                     ");
		rte.setEndereco(scr.nextLine());

		System.out.println("|Horario de abertura:                         ");
		rte.setHorarioAbrir(scr.nextLine());

		System.out.println("|Horario de fechamento:                       ");
		rte.setHorarioFechar(scr.nextLine());

		this.lista.add(rte);
		this.salvarTxt(this.lista);
		System.out.println("***RESTAURANTE CADASTRADO COM SUCESSO!!!***");

	}

	public void salvarTxt(ArrayList<Restaurante> restaurantes) {
	
		//GRAVAR OS DADOS EM ARQUIVO.TXT
		try {
			//criando e salvando char set
			PrintWriter printWriter = new PrintWriter("delivery.data.txt", "UTF-8");

			for (Restaurante restaurante : restaurantes) {
				printWriter.println(restaurante.getnomeRestaurante());
				printWriter.println(restaurante.getEndereco());
				printWriter.println(restaurante.getHorarioAbrir());
				printWriter.println(restaurante.getHorarioFechar());
				printWriter.println("\n");
				
			}
			printWriter.flush();
			printWriter.close();
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	public void lerTxt() {
		
		String file = "delivery.data.txt";
		String line = null;
		List<String> list = new ArrayList<String>();
		try {
			FileReader fileReader = new FileReader(file);
			BufferedReader buffedReader = new BufferedReader(fileReader);
			
			while ((line = buffedReader.readLine()) != null) {
				System.out.println(line);
				list.add(line);
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	
	@Override
	public void mostrar() {
		if (this.lista.isEmpty()) {
			System.out.println("Não há restaurantes cadastrados!");
		} else {
			System.out.println(this.lista);
		}

	}

	@Override
	public void editar() {
		System.out.println("Qual restaurante voce quer editar?");

		for (int i = 0; i < lista.size(); i++) {
			System.out.println(i + "-" + lista.get(i).getnomeRestaurante());
		}
		int indexRestauranteSelecionado = scr.nextInt();
		Restaurante restauranteSelecionado = lista.get(indexRestauranteSelecionado);

		System.out.println("Nome: ");
		scr.nextLine();
		restauranteSelecionado.setnomeRestaurante(scr.nextLine());
		System.out.println("Endereco: ");
		restauranteSelecionado.setEndereco(scr.nextLine());
		System.out.println("Horario de abertura: ");
		restauranteSelecionado.setHorarioAbrir(scr.nextLine());
		System.out.println("Horario de fechamento: ");
		restauranteSelecionado.setHorarioFechar(scr.nextLine());

	}

}
