package model;

import java.util.ArrayList;
import java.util.Scanner;

public class Login {

	
	
	Scanner sc = new Scanner(System.in);
	private ArrayList<Usuario> usuarios;
	private ArrayList<Restaurante> restaurante;
	FazerPedido fp = new FazerPedido(restaurante);
	
	public Login(ArrayList<Usuario> usuarios, ArrayList<Restaurante> restaurante) {
		super();
		this.usuarios = usuarios;
		this.restaurante = restaurante;
	}

	public void escolherUsuario() {

		System.out.println("Qual Usuario deseja utilizar?");

		for (int i = 0; i < usuarios.size(); i++) {
			System.out.println(i + "-" + usuarios.get(i).getNome());
		}
		int indexUsuarioSelecionado = sc.nextInt();
		Usuario usuarioSelecionado = usuarios.get(indexUsuarioSelecionado);
		int opcao;

		do {
			System.out.println("_________________________");
			System.out.println("|*** PEDIDOS ***	     |");
			System.out.println("|________________________|");
			System.out.println("|1 - Fazer Pedido        |");
			System.out.println("|2 - Mostrar Pedidos     |");
			System.out.println("|Digite a opcao desejada |");
			opcao = sc.nextInt();
			System.out.println("|________________________|");

			switch (opcao) {
			case 1:
				if(restaurante.isEmpty()) {
					System.out.println("Nao ha restaurantes cadastrados para poder fazer um pedido...");
				}else {
					fp.pedidos();
				}
				break;

			case 2:
				fp.mostrarPedidos();
				break;
			}
		} while (opcao != 0);

	}
}
