package model;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;

public class CadastroUsuario extends Cadastro {
	
	Scanner scuser = new Scanner(System.in);
	
	private ArrayList<Usuario> lista;
	// ArrayList

	public ArrayList<Usuario> getLista() {
		return lista;
	}

	public CadastroUsuario(ArrayList<Usuario> lista) {
		super();
		this.lista = lista;
	}

	public void setLista(ArrayList<Usuario> lista) {
		this.lista = lista;
	}

	// adicionar usuario
	public void adicionarUser(Usuario userUm) {
		this.lista.add(userUm);
	}

	@Override
	public String toString() {
		return "Usuarios: " + lista;
	}

	@Override
	public void cadastrar() {
		Usuario userUm = new Usuario();
		// atributo para MenuUser

		System.out.println(" ______________________________________________ ");
		System.out.println("|               CADASTRAR USUARIO              |");
		System.out.println("|______________________________________________|");
		System.out.println("|                                              |");
		System.out.println("| Digite o seu nome:                           |");
		userUm.setNome(scuser.nextLine());
		System.out.println("| Digite seu E-mail:                           |");
		userUm.setEmail(scuser.nextLine());
		// Inserindo CPF - Validador de 11 digitos
		do {
			System.out.println("| Digite seu CPF (somente numeros):        	   |");
			userUm.setCpf(scuser.nextLine());
			if (userUm.getCpf().length() < 11 || userUm.getCpf().length() > 11) {
				System.out.println("ERRO! CPF INVALIDO!");
			}
		} while (userUm.getCpf().length() < 11 || userUm.getCpf().length() > 11);

		System.out.println("| Digite seu Endereco:                         |");
		userUm.setEndereco(scuser.nextLine());
		// Inserindo telefone - validador de 9 digitos com DO e IF
		do {
			System.out.println("| Digite seu numero de telefone (com o DDD):|");
			userUm.setTelefone(scuser.nextLine());
			if (userUm.getTelefone().length() < 11) {
				System.out.println("ERRO! TELEFONE INVALIDO!");
			}
		} while (userUm.getTelefone().length() < 11);
		System.out.println("\n");

		this.lista.add(userUm);
		System.out.println("|        USUARIO CADASTRADO COM SUCESSO!       |");
		System.out.println("|______________________________________________|");

	}

	@Override
	public void mostrar() {

		if (this.lista.isEmpty()) {
			System.out.println("Não há usuários cadastrados!");
		} else {
			System.out.println(this.lista);
		}
	}

	@Override
	public void editar() {
		System.out.println("Qual Usuario deseja  editar?");

		for (int i = 0; i < lista.size(); i++) {
			System.out.println(i + "-" + lista.get(i).getNome());
		}
		int indexUsuarioSelecionado = scuser.nextInt();
		Usuario usuarioSelecionado = lista.get(indexUsuarioSelecionado);

		System.out.println("Nome: ");
		scuser.nextLine();
		usuarioSelecionado.setNome(scuser.nextLine());
		do {
			System.out.println("CPF (somente numeros): ");
			usuarioSelecionado.setCpf(scuser.nextLine());
			if (usuarioSelecionado.getCpf().length() < 11 || usuarioSelecionado.getCpf().length() > 11) {
				System.out.println("ERRO! CPF INVALIDO!");
			}
		} while (usuarioSelecionado.getCpf().length() < 11 || usuarioSelecionado.getCpf().length() > 11);
		System.out.println("Endereco: ");
		usuarioSelecionado.setEndereco(scuser.nextLine());
		do {
			System.out.println("Digite seu numero de telefone (com o DDD): ");
			usuarioSelecionado.setTelefone(scuser.nextLine());
			if (usuarioSelecionado.getTelefone().length() < 11) {
				System.out.println("ERRO! TELEFONE INVALIDO!");
			}
		} while (usuarioSelecionado.getTelefone().length() < 11);
		System.out.println("*** USUARIO EDITADO COM SUCESSO! ***");
	}

}
