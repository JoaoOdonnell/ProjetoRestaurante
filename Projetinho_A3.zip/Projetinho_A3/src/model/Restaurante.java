package model;

import java.util.ArrayList;

public class Restaurante {
	
	private ArrayList<Prato> pratos = new ArrayList<>();
	
	public ArrayList<Prato> getPratos() {
		return pratos;
	}
	public void setPratos(ArrayList<Prato> pratos) {
		this.pratos = pratos;
	}
	
	//definindo atributos
	private String nomeRestaurante;
	private String endereco;
	private String horarioAbrir;
	private String horarioFechar;
	
	//encapsulamento
	public String getnomeRestaurante() {
		return nomeRestaurante;
	}
	public void setnomeRestaurante(String nomeRestaurante) {
		this.nomeRestaurante = nomeRestaurante;
	}
	
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	
	public String getHorarioAbrir() {
		return horarioAbrir;
	}
	public void setHorarioAbrir(String horarioAbrir) {
		this.horarioAbrir = horarioAbrir;
	}

	public String getHorarioFechar() {
		return horarioFechar;
	}
	public void setHorarioFechar(String horarioFechar) {
		this.horarioFechar = horarioFechar;
	}
	@Override
	public String toString() {
		return "Restaurante \nRestaurante " + nomeRestaurante + "\nEndereco: " + endereco + "\nHorarios: " + horarioAbrir;
	}
	
	
}
