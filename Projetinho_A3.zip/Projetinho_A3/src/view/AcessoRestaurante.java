package view;

import java.util.ArrayList;
import java.util.Scanner;
import model.CadastroPratos;
import model.CadastroRestaurante;
import model.Restaurante;

public class AcessoRestaurante {

	private ArrayList<Restaurante> restaurante;
	
	public AcessoRestaurante(ArrayList<Restaurante> restaurante) {
		super();
		this.restaurante = restaurante;
	}

	public void MenuRestaurante() {
		
		CadastroRestaurante cr = new CadastroRestaurante(restaurante);
		CadastroPratos cp = new CadastroPratos(cr.getLista());
		MenuAcessos mn = new MenuAcessos(restaurante);
		Scanner scres = new Scanner(System.in);
		cr.lerTxt();
		
		int op;

		//Menu restaurante
		do {
			System.out.println(" __________________________________________");
			System.out.println("|            Sistema Restaurante           |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar Restaurante				   ");
			System.out.println("| 2- Cadastrar Prato			           ");
			System.out.println("| 3- Editar restaurante	                   ");
			System.out.println("| 4- Editar Prato		                   ");
			System.out.println("| 5- Voltar ao Menu principal              ");
			System.out.println("| 0- Sair                                  ");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			op = scres.nextInt();
			System.out.println("|__________________________________________|");

			switch (op) {
			case 1:
				cr.cadastrar();
				break;

			case 2:
				cp.cadastrar();
				break;

			case 3:
				if(cr.getLista().isEmpty()) {
					System.out.println("*** NAO HA RESTAURANTES PARA EDITAR ***");
				}else {
					cr.editar();
				}
				break;

			case 4:
				Restaurante restaurante = new Restaurante();
				if(restaurante.getPratos().isEmpty()) {
					System.out.println("*** NAO HA PRATOS PARA EDITAR! ***");
				}else{
					cp.editar();
				}
				break;
			
			case 5:
				mn.setRestaurantes(getRestaurante());
				mn.MenuPrincipal();
				break;

			}
		} while (op != 0);
	}
	
	public ArrayList<Restaurante> getRestaurante (){
		return this.restaurante;
	}
}
