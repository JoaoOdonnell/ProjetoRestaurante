package view;


import java.util.ArrayList;
import java.util.Scanner;
import model.CadastroUsuario;
import model.Login;
import model.Restaurante;
import model.Usuario;

public class AcessoUsuario {

	private ArrayList<Usuario> users = new ArrayList<Usuario>();
	private ArrayList<Restaurante> restaurante;
	
	public AcessoUsuario(ArrayList<Restaurante> restaurante) {
		super();
		this.restaurante = restaurante;
	}

	public void MenuDoUsuario(){

		MenuAcessos menu = new MenuAcessos(restaurante);
		Scanner scUser = new Scanner(System.in);
		CadastroUsuario cu = new CadastroUsuario(users);
		Login login = new Login(users,restaurante);
		
		
		int opcao2;

		do {

			System.out.println(" __________________________________________");
			System.out.println("|            Sistema de Usuario            |");
			System.out.println("|__________________________________________|");
			System.out.println("|                                          |");
			System.out.println("| 1- Cadastrar				               |");
			System.out.println("| 2- Editar usuario				           |");
			System.out.println("| 3- Login	    		          		   |");
			System.out.println("| 4- Voltar pro Menu Principal			   |");
			System.out.println("| 0- Sair                                  |");
			System.out.println("|__________________________________________|");
			System.out.println("|         Digite a opcao desejada          |");
			opcao2 = scUser.nextInt();
			System.out.println("|__________________________________________|");

			switch (opcao2) {
			case 1:
				cu.cadastrar();
				break;

			case 2:
				cu.editar();
				break;

			case 3:
				if (this.users.isEmpty()) {
					System.out.println("Nao ha usuarios para logar!");
				} else {
					login.escolherUsuario();
				}
				break;

			case 4:
				menu.setRestaurantes(this.restaurante);
				menu.MenuPrincipal();
				break;

			case 0:
				System.out.println("Sistema Encerrado.");
				break;

			}
		} while (opcao2 != 0);
		scUser.close();
	}
	
}